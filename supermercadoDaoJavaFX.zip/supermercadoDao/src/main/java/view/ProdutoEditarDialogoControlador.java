package view;

import java.text.NumberFormat;
import java.util.Locale;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import modelo.Produto;
import utilidade.DateUtil;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class ProdutoEditarDialogoControlador {

    @FXML
    private TextField nomeField;
    @FXML
    private TextField precoField;
    @FXML
    private TextField dataAddField;
    @FXML
    private TextField descricaoField;


    private Stage dialogStage;
    private Produto produto;
    private boolean okClicked = false;

    @FXML
    private void initialize() 
    {
    }

    public void setDialogStage(Stage dialogStage) 
    {
        this.dialogStage = dialogStage;
    }

    public void setProduto(Produto produto) 
    {
        this.produto = produto;

        nomeField.setText(produto.getNome());
        descricaoField.setText(produto.getDescricao());
        
        String precoString = String.valueOf(produto.getPreco());
        precoString = precoString.replace(".",",");
        precoField.setText(precoString);
        
        dataAddField.setText(DateUtil.format(produto.getDataAdd()));
        dataAddField.setPromptText("dd.mm.yyyy");
    }

    public boolean isOkClicked() 
     {
        return okClicked;
    }

    @FXML
    private void handleOk() 
    {
        if (isInputValid()) 
        {
            produto.setNome(nomeField.getText());
            produto.setDescricao(descricaoField.getText());
            
            String precoString = precoField.getText();
            precoString = precoString.replace(",",".");
            precoString = precoString.replace(".",",");
            float precoFloat = Float.parseFloat(precoString);
            produto.setPreco(precoFloat);
            
            produto.setDataAdd(DateUtil.parse(dataAddField.getText().replace("/", "-")));

            okClicked = true;
            dialogStage.close();
        }
    }

    @FXML
    private void handleCancel() 
    {
        dialogStage.close();
    }

    private boolean isInputValid() {
        String errorMessage = "";

        if (nomeField.getText() == null || nomeField.getText().length() == 0 || nomeField.getAccessibleText().length() > 100) 
        {
            errorMessage += "Nome inv�lido!\n"; 
        }
        if (descricaoField.getText() == null || descricaoField.getText().length() == 0 || descricaoField.getAccessibleText().length() > 300) 
        {
            errorMessage += "Descri��o inv�lida!\n"; 
        }
        

        if (precoField.getText() == null || precoField.getText().length() <= 0) 
        {
            errorMessage += "Pre�o inv�lido!\n"; 
        } 
        else 
        {
            try 
            {
                String precoFieldString = precoField.getText().replace(",",".");
                Float.parseFloat(precoFieldString);
            } 
            
            catch (NumberFormatException e) 
            {
                errorMessage += "Pre�o inv�lido! (deve apenas conter n�meros e v�rgula)\n"; 
            }
        }

        
        if (dataAddField.getText() == null || dataAddField.getText().length() == 0) 
        {
            errorMessage += "Data de atribui��o inv�lida!\n";
        } 
        else 
        {
        	String dataString = dataAddField.getText().replace("/","-");	
            if (!DateUtil.dataValida(dataString)) 
            {
                errorMessage += "Data de atribui��o inv�lida! (Use o formato dia/m�s/ano)\n";
            }
        }
        

        if (errorMessage.length() == 0) 
        {
            return true;
        } 
        else 
        {
        	Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Campos Inv�lidos");
            alert.setHeaderText("Por favor, corrija os campos inv�lidos");
            alert.setContentText(errorMessage);
            alert.showAndWait();
                
            return false;
        }
    }
}