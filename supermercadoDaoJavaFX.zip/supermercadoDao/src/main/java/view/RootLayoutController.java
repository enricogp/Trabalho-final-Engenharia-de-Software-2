package view;

import javafx.fxml.FXML;
import modelo.Produto;
import principal.Aplicacao;


public class RootLayoutController 
{

    private Aplicacao aplicacao;

    @FXML
    private void handleNovo() 
    {
    	 Produto tempProd = new Produto();
         boolean okClicked = aplicacao.mostrarProdutoDialogoEditar(tempProd);
         if (okClicked) 
         {
         	aplicacao.getProdutoData().add(tempProd);
         	Aplicacao.getDao().inserir(tempProd);
         }
    }

    @FXML
    private void handlePesquisar() 
    {

    }
    
    public void setMainApp(Aplicacao aplicacao) 
    {
        this.aplicacao = aplicacao;
    }

}
