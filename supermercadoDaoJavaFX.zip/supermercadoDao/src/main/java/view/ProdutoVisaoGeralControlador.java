package view;

import java.text.NumberFormat;
import java.util.Locale;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import modelo.Produto;
import principal.Aplicacao;
import utilidade.DateUtil;

public class ProdutoVisaoGeralControlador 
{
    @FXML
    private TableView<Produto> produtoTable;
    @FXML
    private TableColumn<Produto, Number> idColumn;
    @FXML
    private TableColumn<Produto, String> nomeColumn;

    @FXML
    private Label nomeLabel;
    @FXML
    private Label descricaoLabel;
    @FXML
    private Label precoLabel;
    @FXML
    private Label dataAddLabel;

    // Reference to the main application.
    private Aplicacao aplicacao;

    public ProdutoVisaoGeralControlador() 
    {
    }

    @FXML
    private void initialize() 
    {
    	idColumn.setCellValueFactory(cellData -> cellData.getValue().idProperty());
        nomeColumn.setCellValueFactory(cellData -> cellData.getValue().nomeProperty());
        mostrarDetalhesProduto(null);

        
        produtoTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> mostrarDetalhesProduto(newValue));
    }

    public void setMainApp(Aplicacao aplicacao) 
    {
        this.aplicacao = aplicacao;
        produtoTable.setItems(aplicacao.getProdutoData());
    }
    
    private void mostrarDetalhesProduto(Produto produto) 
    {
        if (produto != null) {
            nomeLabel.setText(produto.getNome());
            descricaoLabel.setText(produto.getDescricao());
            
            String precoString = String.valueOf(produto.getPreco()).replace(".", ",");
            precoLabel.setText(precoString);

            dataAddLabel.setText(DateUtil.format(produto.getDataAdd()));
        } 
        else
        {
        	nomeLabel.setText("");
        	descricaoLabel.setText("");
        	precoLabel.setText("");
            dataAddLabel.setText("");
        }
    }
    
    @FXML
    private void handleApagarProduto() 
    {
    	int selectedIndex = produtoTable.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) 
        {
        	Produto prodSelecionado = produtoTable.getSelectionModel().getSelectedItem();
        	Aplicacao.getDao().deletar(prodSelecionado);
        	produtoTable.getItems().remove(selectedIndex);
        } 
        else 
        {
          
    	Alert alert = new Alert(AlertType.WARNING);
            	alert.setTitle("Nenhuma sele��o");
            	alert.setHeaderText("Nenhuma Pessoa Selecionada");
            	alert.setContentText("Por favor, selecione uma pessoa na tabela.");

            	alert.showAndWait();
        }
    }
    
    @FXML
    private void handleNovoProduto() 
    {
        Produto tempProd = new Produto();
        boolean okClicked = aplicacao.mostrarProdutoDialogoEditar(tempProd);
        if (okClicked) 
        {
        	//aplicacao.getProdutoData().add(tempProd);
        	aplicacao.getProdutoData().add(tempProd);
        	Aplicacao.getDao().inserir(tempProd);
        }
    }
    
    @FXML
    private void handleEditarProduto() 
    {
        Produto prodSelecionado = produtoTable.getSelectionModel().getSelectedItem();
        
        if (prodSelecionado != null) 
        {
            boolean okClicked = aplicacao.mostrarProdutoDialogoEditar(prodSelecionado);
            if (okClicked) 
            {
                mostrarDetalhesProduto(prodSelecionado);
            }

        }
        
        else 
        {
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("Nenhuma sele��o");
            alert.setHeaderText("Nenhuma Pessoa Selecionada");
            alert.setContentText("Por favor, selecione uma pessoa na tabela.");
            alert.showAndWait();
        }
    }
}