package utilidade;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;


public class DateUtil {
	
	private static final String PADRAO = "yyyy.MM.dd";
	
	private static final DateTimeFormatter FORMATADOR_DATA = 
			DateTimeFormatter.ofPattern(PADRAO);
	

    public static String format(LocalDate date) {
        if (date == null) {
            return null;
        }
        return FORMATADOR_DATA.format(date);
    }

    public static LocalDate parse(String dateString) {
        try {
        	return FORMATADOR_DATA.parse(dateString, LocalDate::from);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    public static boolean dataValida(String dateString) {
    	return DateUtil.parse(dateString) != null;
    }
}
