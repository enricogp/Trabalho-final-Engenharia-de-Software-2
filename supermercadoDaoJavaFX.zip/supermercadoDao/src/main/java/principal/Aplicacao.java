package principal;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import dao.ProdutoDAO;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import modelo.Produto;
import view.ProdutoEditarDialogoControlador;
import view.ProdutoVisaoGeralControlador;

public class Aplicacao extends Application
{
	 private Stage primaryStage;
	 private BorderPane rootLayout;
	 private ObservableList<Produto> produtoData = FXCollections.observableArrayList();
	 private static ProdutoDAO dao;
	 
	 public Aplicacao() 
	 {
	 }
	  

		public ObservableList<Produto> getProdutoData() 
		{
			return produtoData;
		}
		
		public static ProdutoDAO getDao() 
	 	{
			return dao;
	 	}
	 
		@Override
	    public void start(Stage primaryStage){
			this.primaryStage = primaryStage;
	        this.primaryStage.setTitle("Estoque de Produtos usando Hibernate e JavaFX");
	        this.primaryStage.getIcons().add(new Image("file:/resources/images/iconfinder_Warehouse_32.png"));
	        
	        
	        dao = new ProdutoDAO();
	        
	        iniciarRootLayout();
	        
	        mostrarProdutoVisaoGeral();
	        /*
	        List<Produto> lista = dao.getTodos();
			 
			for (int i = 0; i < (lista.size() - 1); i++) 
			{
				produtoData.add(new Produto(lista.get(i).getId(), lista.get(i).getNome()));
			}*/
	    }
	 
	 public void iniciarRootLayout() 
	 {
	        try 
	        {
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/RootLayout.fxml"));
	            rootLayout = (BorderPane) loader.load();
	            
	            Scene scene = new Scene(rootLayout);
	            primaryStage.setScene(scene);
	            primaryStage.show();
	        } 
	        catch (IOException e) 
	        {
	            e.printStackTrace();
	        }
	 }
	 
	 public void mostrarProdutoVisaoGeral() 
	 {
		 try 
		 {
		        FXMLLoader loader = new FXMLLoader();
		        loader.setLocation(Aplicacao.class.getResource("/view/ProdutoVisaoGeral.fxml"));
		        AnchorPane produtoVisaoGeral = (AnchorPane) loader.load();

		        rootLayout.setCenter(produtoVisaoGeral);

		        ProdutoVisaoGeralControlador controller = loader.getController();
		        controller.setMainApp(this);

		 } 
		 catch (IOException e) 
		 {
		        e.printStackTrace();
		 }
	 }
	 
	 public Stage getPrimaryStage() 
	 	{
			return primaryStage;
		}
	 
	 public boolean mostrarProdutoDialogoEditar(Produto produto) 
	 {
		    try 
		    {
		        FXMLLoader loader = new FXMLLoader();
		        loader.setLocation(Aplicacao.class.getResource("/view/ProdutoEditarDialogo.fxml"));
		        AnchorPane page = (AnchorPane) loader.load();

		        Stage dialogStage = new Stage();
		        dialogStage.setTitle("Editar Produto");
		        dialogStage.initModality(Modality.WINDOW_MODAL);
		        dialogStage.initOwner(primaryStage);
		        Scene scene = new Scene(page);
		        dialogStage.setScene(scene);

		        ProdutoEditarDialogoControlador controller = loader.getController();
		        controller.setDialogStage(dialogStage);
		        controller.setProduto(produto);

		        dialogStage.showAndWait();

		        return controller.isOkClicked();
		    } 
		    
		    catch (IOException e) 
		    {
		        e.printStackTrace();
		        return false;
		    }
		}
	
	public static void main(String[] args) 
	{
		launch(args);
		
		/**
		
		
		boolean repetir = true;
		
		while(repetir == true) 
		{
			Scanner entrada = new Scanner(System.in);
			
			ProdutoDAO dao = new ProdutoDAO();
			
			System.out.println("-Digite 1 para inserir produtos, 2 para editar, 3 para remover,  4 para listagem, 5 para pesquisar, ou 6 para sair-");
			String escolha = entrada.nextLine();
			
			if (escolha.contentEquals("1")) 
			{
				System.out.println("\nInsira o nome do produto:");
				String nome = entrada.nextLine();
				System.out.println("\nInsira a descri��o do produto:");
				String descricao = entrada.nextLine();
				System.out.println("\nInsira o pre�o do produto:");
				float preco = Float.parseFloat(entrada.nextLine());
				Produto prod = new Produto();
				prod.setNome(nome);
				prod.setDescricao(descricao);
				prod.setPreco(preco);
				
				dao.inserir(prod);
			}
			else if (escolha.contentEquals("2")) 
			{
				System.out.println("\nInsira o ID do produto que deseja editar:");
				int id = Integer.parseInt(entrada.nextLine());
				
				Produto prod = dao.getPeloID(id);
				System.out.println("Digite o novo nome:");
				String novoNome = entrada.nextLine();
				prod.setNome(novoNome);
				System.out.println("Digite a nova descri��o nome:");
				String novaDescricao = entrada.nextLine();
				prod.setNome(novoNome);
				System.out.println("Digite o novo preco:");
				float novoPreco = Float.parseFloat(entrada.nextLine());
				prod.setNome(novoNome);
				prod.setDescricao(novaDescricao);
				prod.setPreco(novoPreco);
				
				dao.alterar(prod);
			}
			else if (escolha.contentEquals("3")) 
			{
				System.out.println("\nInsira o ID do produto que deseja remover:");
				int id = Integer.parseInt(entrada.nextLine());
				Produto prod = dao.getPeloID(id);
				dao.deletar(prod);
			}
			else if (escolha.contentEquals("4")) 
			{
				System.out.println("\nDigite 1 para ordenar por ID, digite 2 para ordenar por nome");
				String escolhaOrd = entrada.nextLine();
				List<Produto> lista = null;
				
				if (escolhaOrd.contentEquals("2")) 
				{
					lista = dao.getTodosOrdNome();
				}
				
				else 
				{
					lista = dao.getTodos();
				}
				
				System.out.println(relatorio(lista));
				
				System.out.println("\nAperte Enter para continuar");
				
				String pausaLista = entrada.nextLine();
			}
			else if (escolha.contentEquals("5")) 
			{
				System.out.println("\nDigite 1 para pesquisar por ID, digite 2 para pesquisar por nome");
				String escolhaPesq = entrada.nextLine();
				if (escolhaPesq.contentEquals("2")) 
				{
					System.out.println("\nDigite o nome que deseja pesquisar");
					String escolhaPesq2 = entrada.nextLine();
					Produto prod = dao.getPorNome(escolhaPesq2);
					System.out.println(relatorioEspecifico(prod));
					String pausaPesq = entrada.nextLine();
					
				}
				else 
				{
					System.out.println("\nDigite o ID que deseja pesquisar");
					int escolhaPesq2 = Integer.parseInt(entrada.nextLine());
					Produto prod = dao.getPeloID(escolhaPesq2);
					System.out.println(relatorioEspecifico(prod));
					String pausaPesq = entrada.nextLine();	
				}
				
				System.out.println("\nAperte Enter para continuar");
			}
			else 
			{
				repetir = false;
				System.out.println("FIM");
			}
		}
		
		*/
		
	}
	/**
	public static String relatorio (List<Produto> lista) 
	{
		String msg = "\n-Lista de produtos-\n";
		
		for (Produto prod :lista) 
		{
			msg += "\nId: " + prod.getId() + "\nNome: " + prod.getNome() + "\nDescricao: " + prod.getDescricao() + "\nPre�o: " + prod.getPreco() + "\n";
		}
		
		return msg;
	}
	
	public static String relatorioEspecifico (Produto prod) 
	{
		String msg = "\nId: " + prod.getId() + "\nNome: " + prod.getNome() + "\nDescricao: " + prod.getDescricao() + "\nPre�o: " + prod.getPreco() + "\n";
		
		return msg;
	}
	*/

}
