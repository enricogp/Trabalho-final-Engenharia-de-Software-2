package modelo;

import java.time.LocalDate;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import javafx.beans.property.FloatProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleFloatProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


@Entity (name = "PRODUTO")  
public class Produto 
{
	@Id
	@Column(name="id", nullable=false, unique=true)
	private  IntegerProperty id;
	private  StringProperty nome;
	private  StringProperty descricao;
	private  FloatProperty preco;
	private ObjectProperty<LocalDate> dataAdd;

	public Produto() 
	{
		this(0, null);
	}
	
	
	public Produto(int id, String nome) 
	{
		this.id = new SimpleIntegerProperty(id);
		this.nome = new SimpleStringProperty(nome);
		this.descricao = new SimpleStringProperty("");
		this.preco = new SimpleFloatProperty(0.00f);
		this.dataAdd = new SimpleObjectProperty<LocalDate>(LocalDate.of(2020, 1, 1));
	}
	
	public String getNome() 
	{
		return nome.get();
	}

	public void setNome(String nome) 
	{
		this.nome.set(nome);
	}
	
	public StringProperty nomeProperty() 
	{
		return nome;
	}

	public String getDescricao() 
	{
		return descricao.get();
	}

	public void setDescricao(String descricao) 
	{
		this.descricao.set(descricao);
	}
	
	public StringProperty descricaoProperty() 
	{
		return descricao;
	}

	public int getId() {
		return id.get();
	}

	public void setId(int id) 
	{
		this.id.set(id);
	}
	
	public IntegerProperty idProperty() {
		return id;
	}
	
	public float getPreco() {
		return preco.get();
	}

	public void setPreco(float preco) 
	{
		this.preco.set(preco);
	}
	
	public FloatProperty precoProperty() {
		return preco;
	}

	
	public LocalDate getDataAdd() {
		//return dataAdd.get();
		return  dataAddProperty().get();
	}

	public void setDataAdd(LocalDate dataAdd) {
		//this.dataAdd.set(dataAdd);
		dataAddProperty().set(dataAdd);;
	}
	
	public ObjectProperty<LocalDate> dataAddProperty() {
		return dataAdd;
	}
	
}